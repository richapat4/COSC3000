## Resource links in dataset 

Listed below are useful links in this dataset : 

* Link(https://api.resourcewatch.org/v1/download?sql=select%2520*%2520from%25201de2af1c-5e5e-4a33-b8f1-8c8f9d000e49&format=csv)
* Link(https://api.resourcewatch.org/v1/download?sql=select%2520*%2520from%25201de2af1c-5e5e-4a33-b8f1-8c8f9d000e49&format=json)
